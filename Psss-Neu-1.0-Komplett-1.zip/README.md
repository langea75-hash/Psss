# Psss 🤫 – kompletter Neustart

Enthalten:
- Anmeldung
- Registrierung
- Benutzername + PIN
- Einladungscode
- Freunde hinzufügen
- Einzelchat
- Gruppenchat
- Gruppen erstellen
- ordentliches responsives Design
- GitHub-Pages-tauglich

Einladungscode:
PSSS-2026

Wichtig:
Diese Version speichert Konten und Nachrichten lokal im Browser.
Für echten Chat zwischen verschiedenen Geräten wird später Firebase sauber ergänzt.

GitHub:
1. ZIP entpacken.
2. Alle Dateien in das Hauptverzeichnis des Repositorys `Psss` hochladen.
3. Vorhandene Dateien ersetzen.
4. GitHub Pages neu laden.
