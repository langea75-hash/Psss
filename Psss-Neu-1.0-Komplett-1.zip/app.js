const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const get=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f}catch{return f}};
const set=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
let currentUser=null,activeChat=null;

const users=()=>get("psss_new_users",[]);
const chats=()=>get(`psss_new_chats_${currentUser}`,[]);
const saveChats=v=>set(`psss_new_chats_${currentUser}`,v);
const messages=id=>get(`psss_new_messages_${currentUser}_${id}`,[]);
const saveMessages=(id,v)=>set(`psss_new_messages_${currentUser}_${id}`,v);

function esc(s){
  const d=document.createElement("div");
  d.textContent=s;
  return d.innerHTML;
}

function setTab(which){
  const login=which==="login";
  $("#loginForm").classList.toggle("hidden",!login);
  $("#registerForm").classList.toggle("hidden",login);
  $("#loginTab").classList.toggle("active",login);
  $("#registerTab").classList.toggle("active",!login);
  $("#status").textContent="";
  $("#status").style.color="#b42318";
}
$("#loginTab").onclick=()=>setTab("login");
$("#registerTab").onclick=()=>setTab("register");

$("#registerForm").onsubmit=e=>{
  e.preventDefault();
  const displayName=$("#displayName").value.trim();
  const username=$("#registerUser").value.trim().toLowerCase();
  const pin=$("#registerPin").value.trim();
  const invite=$("#inviteCode").value.trim();

  if(invite!=="PSSS-2026")return $("#status").textContent="Einladungscode ist falsch.";
  if(!/^[a-z0-9._-]{3,24}$/i.test(username))return $("#status").textContent="Benutzername: 3–24 Zeichen.";
  if(!/^\d{4,8}$/.test(pin))return $("#status").textContent="PIN: 4–8 Ziffern.";

  const list=users();
  if(list.some(u=>u.username===username))return $("#status").textContent="Benutzername ist bereits vergeben.";

  list.push({displayName,username,pin});
  set("psss_new_users",list);

  $("#loginUser").value=username;
  $("#loginPin").value=pin;
  setTab("login");
  $("#status").style.color="#16803a";
  $("#status").textContent="Registrierung erfolgreich. Jetzt anmelden.";
};

$("#loginForm").onsubmit=e=>{
  e.preventDefault();
  const username=$("#loginUser").value.trim().toLowerCase();
  const pin=$("#loginPin").value.trim();
  const u=users().find(x=>x.username===username&&x.pin===pin);

  if(!u){
    $("#status").style.color="#b42318";
    return $("#status").textContent="Benutzername oder PIN ist falsch.";
  }
  login(u);
};

function login(u){
  currentUser=u.username;
  set("psss_new_session",currentUser);
  $("#authPage").classList.add("hidden");
  $("#appPage").classList.remove("hidden");
  $("#me").textContent=u.displayName||u.username;

  if(!chats().length){
    saveChats([
      {id:crypto.randomUUID(),type:"friend",name:"Testfreund",members:["Testfreund"]},
      {id:crypto.randomUUID(),type:"group",name:"Testgruppe",members:[u.displayName||u.username,"Steffi","Martin"]}
    ]);
  }
  renderChats();
}

$("#logoutBtn").onclick=()=>{
  localStorage.removeItem("psss_new_session");
  location.reload();
};

function renderChats(){
  $("#chatList").innerHTML=chats().map(c=>`
    <div class="chat-item ${activeChat===c.id?"active":""}" data-id="${c.id}">
      <strong>${esc(c.name)}</strong>
      <div class="meta">${c.type==="group" ? `Gruppe · ${c.members.length} Mitglieder` : "Einzelchat"}</div>
    </div>`).join("");

  $$(".chat-item").forEach(el=>el.onclick=()=>openChat(el.dataset.id));
}

function openChat(id){
  activeChat=id;
  const c=chats().find(x=>x.id===id);
  $("#emptyChat").classList.add("hidden");
  $("#chatPanel").classList.remove("hidden");
  $("#chatTitle").textContent=c.name;
  $("#chatMeta").textContent=c.type==="group"?c.members.join(", "):"Einzelchat";
  renderMessages();
  renderChats();
}

function renderMessages(){
  const c=chats().find(x=>x.id===activeChat);
  $("#messages").innerHTML=messages(activeChat).map(m=>`
    <div class="message ${m.mine?"mine":""}">
      ${c?.type==="group" ? `<div class="sender">${esc(m.sender||"")}</div>` : ""}
      <div>${esc(m.text)}</div>
      <div class="time">${esc(m.time)}</div>
    </div>`).join("");
  $("#messages").scrollTop=$("#messages").scrollHeight;
}

$("#messageForm").onsubmit=e=>{
  e.preventDefault();
  const text=$("#messageInput").value.trim();
  if(!text||!activeChat)return;

  const list=messages(activeChat);
  const me=users().find(x=>x.username===currentUser);
  list.push({
    text,
    mine:true,
    sender:me?.displayName||currentUser,
    time:new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})
  });

  saveMessages(activeChat,list);
  $("#messageInput").value="";
  renderMessages();
};

$("#friendBtn").onclick=()=>$("#friendDialog").showModal();

$("#saveFriendBtn").onclick=()=>{
  const name=$("#friendName").value.trim();
  if(!name)return;
  const list=chats();
  list.push({id:crypto.randomUUID(),type:"friend",name,members:[name]});
  saveChats(list);
  $("#friendName").value="";
  $("#friendDialog").close();
  renderChats();
};

$("#groupBtn").onclick=()=>$("#groupDialog").showModal();

$("#saveGroupBtn").onclick=()=>{
  const name=$("#groupName").value.trim();
  if(!name)return;

  const me=users().find(x=>x.username===currentUser);
  const myName=me?.displayName||currentUser;
  const members=$("#groupMembers").value.split(",").map(x=>x.trim()).filter(Boolean);
  if(!members.includes(myName))members.unshift(myName);

  const list=chats();
  list.push({id:crypto.randomUUID(),type:"group",name,members});
  saveChats(list);

  $("#groupName").value="";
  $("#groupMembers").value="";
  $("#groupDialog").close();
  renderChats();
};

const session=get("psss_new_session",null);
if(session){
  const u=users().find(x=>x.username===session);
  if(u)login(u);
}
